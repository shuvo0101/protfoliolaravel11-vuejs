<script setup>
defineProps({});

</script>

<template>
  <h1 class="text-red-600 font-bold text-2xl text-center"> Vacancy Index</h1>
</template>

<style scoped>

</style>
