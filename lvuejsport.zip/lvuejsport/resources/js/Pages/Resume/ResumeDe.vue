<script setup>
</script>

<template>
  <div class="mx-auto w-[760px] h-[1080px] mt-4 text-[12px]">
    <div class="relative overflow-x-auto">
      <table
        class="w-full text-left text-black dark:text-white leading-5"
      >
        <tbody>
        <tr class="bg-white dark:bg-gray-800 dark:border-gray-700">
          <td class="w-[200px] align-top ">
            <table class="w-full text-left border-collapse">
              <tbody>
              <tr class="border-collapse">
                <td class="pt-2 pb-4">
                  <img
                    src="/images/024.jpg"
                    alt="Photo Oksana Bürki"
                    class="block w-[190px] h-auto ml-2"
                  />
                </td>
              </tr>
              <tr class="  border-r border-black">
                <td
                  style="font-family: 'Noto Serif', serif; font-weight: 700; font-size: 24px"
                  class="px-4 py-2 h-[30px]"
                >
                  <h1 class="text-[22px]">Oksana Bürki</h1>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 h-[30px] text-[16px] font-semibold">
                  <p
                    style="font-weight: 400; font-size: 16px"
                    class="inline-block pb-2"
                  >
                    PHP Web Entwicklerin
                  </p>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pt-4 pb-1 h-[30px]">
                  <p style="font-weight: 400; font-size: 12px">Telefon / WhatsApp</p>
                  <p class="accent mb-2 text-lg">+41 76 410 4101</p>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pb-2 h-[30px]">
                  <p class="accent-title">Adresse</p>
                  <p class="text-small">
                    Milchstrasse 6c, <br/>
                    6423 Seewen SZ, Schweiz
                  </p>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pb-2 h-[30px]">
                  <p class="accent-title">Email</p>
                  <p class="text-small block">xenia1898@gmail.com</p>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pb-2 h-[30px]">
                  <div class="accent-title">Telegram</div>
                  <a href="https://t.me/XeniaWeb/" class="text-small block hover:text-red-600" target="_blank">
                    t.me/XeniaWeb
                  </a>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pb-2 h-[30px]">
                  <p class="accent-title">GitHub</p>
                  <a href="https://github.com/XeniaWeb/" class="text-small block hover:text-red-600" target="_blank">
                    github.com/XeniaWeb
                  </a>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pb-4 h-[30px]">
                  <p class="accent-title">Linkedin</p>
                  <a
                    href="https://www.linkedin.com/in/xeniaweb/"
                    class="text-small block hover:text-red-600"
                    target="_blank"
                  >
                    linkedin.com/in/xeniaweb
                  </a>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pt-4 h-[30px]">
                  <p class="inline-block font-bold text-[18px] mb-2">Zusätzliche Fähigkeiten</p>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pb-2 h-[30px]">
                  <p class="text-small pb-2">Workflow: Git GitHub BitBucket Vite Webpack Gulp Docker</p>
                  <p class="text-small pb-2">Tools: PHPStorm, Postman, DockerHub, Mailtrap</p>
                  <p class="text-small pb-2">
                    Frameworks: Laravel InertiaJs Tailwind Vue.js React TypeScript
                  </p>
                  <p class="text-small pb-2">WebDesign: Figma Zeplin Photoshop AdobeXD</p>
                  <p class="text-small pb-2">Sonstiges: PKW-Führerschein</p>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pt-4 h-[30px]">
                  <p class="sub-title inline-block">Arbeitserlaubnis</p>
                </td>
              </tr>
              <tr class="border-r border-black">
                <td class="px-4 pb-2 h-[30px]">
                  <p class=" pb-1 accent">Bewilligung B <span class="text-small">Familienangehöriger</span></p>
                  <p class="text-small pb-2"> in der Schweiz</p>
                  <p class="text-small pb-2">(Familiennachzug berechtigt zur Erwerbstätigkeit)</p>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
          <td class="w-[560px]0 align-top">
            <table class=" w-full text-black dark:text-white">
              <tbody class="align-top">
              <tr>
                <td class="px-4 h-[30px]">
                  <p class="main-title">
                    WEB Entwicklerin
                    <span class="px-3 font-normal text-[20px]"
                    >PHP / Laravel</span
                    >
                  </p>
                </td>
              </tr>
              <tr>
                <td class="px-4 h-[30px] text-[14px]">
                  <p class="text-small pb-1">
                    Backend PHP mit Laravel, objektorientierte PHP-Programmierung, MVC-Muster,
                  </p>
                  <p class="text-small pb-1">
                    PostgreSQL, MySQL (Eloquent), REST-vollständige API mit Laravel || API-Plattform
                  </p>
                  <p class="text-small pb-1">
                    Website-Entwicklung mit Laravel / Blade / InertiaJS / Vue.js - Composition API
                  </p>
                  <p class="text-small pb-1">
                    HTML, CSS3, SASS, Tailwind, JS, Vue.js 3, Vite, Web Standards
                  </p>
                  <p class="text-small pb-1">
                    Docker, GitHub, CI/CD, API-Dokumentation
                  </p>
                  <p class="text-small pb-1">Teamarbeit basierend auf Agile- und Scrum-Prinzipien</p>
                </td>
              </tr>
              <tr>
                <td class="px-4 py-2 h-[30px] ">
                  <p class="sub-title pb-2 border-b border-black">
                    Arbeitserfahrung
                  </p>
                  <table class=" w-full text-black dark:text-white">
                    <tbody>
                    <tr class="text-left">
                      <td class="w-[110px] align-top">
                        <p class="font-semibold">02/2021 - 10/2023</p>
                        <span class="text-small">2 Jahre 10 Monate</span>
                      </td>
                      <td class="px-2 pb-2 align-top">
                        <p class="font-semibold mb-1 text-[14px] inline-block border-b border-black">
                          PHP Backend Developer / Laravel
                        </p>
                        <p class="">
                          <span class="font-semibold text-[14px]">
                            GoCPA, Affiliate Marketing Platform,
                          </span>
                          <a
                            href="https://gocpa.net/"
                            class="text-small hover:text-red-600"
                            target="_blank">gocpa.net
                          </a></p>

                        <p class="text-small">
                          • Entwicklung von Benutzerrollen und Zugriffsverwaltung System <br>
                          • Hinzufügen neuer Entitäten zur Datenbank durch Migrationen, Schreiben von Abfragen über Eloquent, Arbeiten mit Zeilenabfragen PostgreSQL, MySQL<br>
                          • Entwicklung von Schnittstellen für persönliche Accounts
                          (Statistiken, elektronische Dokumentenverwaltung,
                          CRUD-Schnittstellen, Ticketsystem, Mailinglisten, und s.w.)
                          • Layout von Schnittstellen mithilfe Komponenten <br>
                          • MVC-Pattern, das die Laravel-Funktionalität in meiner Arbeit verwendet:
                          Middlewares, Befehle, Dienstanbieter, Beobachter <br>
                          • Anwendung von Git, npm, Artisan-Befehlen, Docker
                        </p>
                      </td>
                    </tr>
                    <tr class="text-left">
                      <td class="w-[110px] align-top">
                        <p class="font-semibold">08/2018 - 01/2021</p>
                        <span class="text-small">2.5 Jahre</span>
                      </td>
                      <td class="px-2 pb-2 align-top">
                        <p class="font-semibold mb-1 text-[14px] inline-block border-b border-black">
                          PHP Web Developer, Full Stack Developer
                        </p>
                        <p class="">
                          <span class="font-semibold">
                            XeniaWeb,
                          </span>
                          <a
                            href="https://xeniaweb.ch/"
                            class="text-small hover:text-red-600"
                            target="_blank">freiberuflich
                          </a></p>

                        <p class="text-small">
                          • Entwicklung von Websites für Privatkunden
                        </p>
                      </td>
                    </tr>
                    <tr class="text-left">
                      <td class="py-1 w-[110px] align-top">
                        <p class="font-semibold">04/2017-08/2018</p>
                        <span class="text-small">1.5 Jahre</span>
                      </td>
                      <td class="px-2 pt-1 pb-2 align-top">
                        <p class="">
                          <span class="font-semibold mb-1 text-[14px] inline-block border-b border-black mr-2">
                            Produktfotograf,
                          </span>
                          <a
                            href="https://xeniaweb.ch/"
                            class="text-small hover:text-red-600"
                            target="_blank"> freiberuflich
                          </a></p>
                      </td>
                    </tr>
                    <tr class="text-left">
                      <td class="w-[110px] align-top py-1">
                        <p class="font-semibold">08/2007-04/2017</p>
                        <span class="text-small">10 Jahre</span>
                      </td>
                      <td class="px-2 pb-2 align-top pt-1">
                        <p class="">
                          <span class="font-semibold mb-1 text-[14px] inline-block border-b border-black mr-2">
                            Regionalmanager,
                          </span>
                          Online-Shop-Management
                        </p>
                        <p class="">
                          <span class="font-semibold">
                            SibAutoSvet Ltd.,</span>Großhandel mit Autolichtern.
                        </p>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2" class="text-small">Ich arbeite seit 1992 ...
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <td class="px-4 py-2 h-[30px] ">
                  <p class="sub-title pb-2 border-b border-black">
                    Ausbildung
                  </p>
                  <p class="text-small pb-1">
                    04/2023 - 09/2023
                    <span class="font-semibold">OTUS,</span> Moskau, Russland
                    Praktischer Kurs: <span class="font-semibold">• Vue.js 3 Developer</span> <a
                    href="https://otus.ru/certificate/dc966ecaa1074cc89f35cb3ca8338e0f/en/" class="hover:text-red-600"
                    target="_blank">(Zertifikat)</a>
                  </p>
                  <p class="text-small pb-1">
                    07/2021 - 01/2022
                    <span class="font-semibold">OTUS,</span> Moskau, Russland
                    Praktischer Kurs: <span class="">• PHP Developer.Professional.</span> <a
                    href="https://otus.ru/certificate/a886355b64e54948a89132790645b563/en/" class="hover:text-red-600"
                    target="_blank">(Zertifikat)</a>
                  </p>
                  <p class="text-small pb-1">
                    03/2020 - 06/2020
                    <span class="font-semibold">LoftSchool,</span> St. Petersburg, Russland
                    Praktischer Kurs: <span class="font-semibold">• Vue.js Advanced Web Development </span><a
                    href="https://loftschool.com/diploma/JL1584462302/en/pdf" class="hover:text-red-600"
                    target="_blank">(Zertifikat)</a>
                  </p>
                  <p class="text-small pb-1">

                    06/2019 - 09/2019
                    <span class="font-semibold">LoftSchool,</span> St. Petersburg, Russland
                    Praktischer Kurs: <span class="font-semibold">• PHP-Programmierung mit Laravel </span><a
                    href="https://loftschool.com/diploma/QP1560523303/en/pdf" class="hover:text-red-600"
                    target="_blank">(Zertifikat)</a>
                  </p>
                  <p class="text-small pb-1">

                    07/2018 - 12/2018
                    <span class="font-semibold">HTML Academy,</span> St. Petersburg, Russland
                    <span class="font-semibold">• PHP-Programmierung und MySQL</span> (Zertifikat) <span class="font-semibold">• HTML / CSS</span> (Zertifikat)
                    <span class="font-semibold">• JavaScript-Programmierung</span> (Zertifikat)
                  </p>
                  <p class="text-small pb-1">
                    1999 - 2001
                    Staatliche Akademie für Architektur und Kunst, Nowosibirsk, Russland
                    • Kurs für Innenarchitektur und Landschaftsbau
                  </p>
                  <p class="text-small pb-1">

                    1998 - 2000
                    Staatliche Universität für Wirtschaft und Management (NSUEM), Nowosibirsk, Russland
                    • Finanzen und Kredit
                  </p>
                  <p class="text-small pb-1">
                    1985 – 1992
                    Institut für Technologie und Design, Nowosibirsk, Russland
                    • Ingenieurabschluss
                    • Technologie der Textil- und Bekleidungsindustrie </p>
                </td>
              </tr>
              <tr>
                <td class="px-4 py-2 h-[30px] ">
                  <p class="sub-title pb-2 border-b border-black">
                    Sprachen
                  </p>
                  <p class="text-[16px] pb-1">
                    <span class="mr-2">Deutsch (B2)</span>
                    <span class="mr-2">Englisch (A2)</span>
                    <span class="mr-2">Russisch (Muttersprache)</span>
                    <span class="mr-2">Französisch (A2)</span>
                  </p>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.main-title {
  font-weight: 800;
  font-size: 22px;
  @apply mb-2 py-2 border-b border-black;
}

.sub-title {
  font-weight: 700;
  font-size: 18px;
  @apply mb-2;
}

.accent-title {
  display: inline-block;
  font-weight: 700;
  font-size: 14px;
}

.accent {
  display: inline-block;
  font-weight: 700;
  line-height: 1.2;
}

.text-small {
  font-weight: 400;
  line-height: 1.4;
  font-size: 12px;
}
</style>
